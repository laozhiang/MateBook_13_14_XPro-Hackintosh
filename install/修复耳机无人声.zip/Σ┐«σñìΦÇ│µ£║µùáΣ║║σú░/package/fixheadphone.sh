#!/bin/bash
/usr/local/bin/hda-verb 0x12 SET_PIN_WIDGET_CONTROL 0x20
/usr/local/bin/hda-verb 0x18 SET_PIN_WIDGET_CONTROL 0x20
/usr/local/bin/hda-verb 0x19 SET_PIN_WIDGET_CONTROL 0x20
/usr/local/bin/hda-verb 0x1b SET_PIN_WIDGET_CONTROL 0x40
/usr/local/bin/hda-verb 0x1d SET_PIN_WIDGET_CONTROL 0x20
/usr/local/bin/hda-verb 0x1e SET_PIN_WIDGET_CONTROL 0x40
/usr/local/bin/hda-verb 0x21 SET_PIN_WIDGET_CONTROL 0xc0

