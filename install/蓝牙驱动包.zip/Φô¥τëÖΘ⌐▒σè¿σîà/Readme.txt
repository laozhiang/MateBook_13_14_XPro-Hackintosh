配置只针对Matebook X Pro 19款
1、 安装VMware fusion
3、双击执行蓝牙脚本目录的 install.command
如果
