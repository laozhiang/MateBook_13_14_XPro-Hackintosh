配置只针对19款
1、 安装VMware fusion
2、将虚拟机目录下“蓝牙启动.zip”解压缩到当前用户目录，虚拟机 目录下
3、双击执行蓝牙脚本目录的 install.command
4、重新启动

18款处理
1.先启动一次虚拟机的linux，然后把蓝牙转给linux，然后关机或挂起。
2.打开虚拟机Tiny的包内容，查看vmware.log文件，搜Bluetooth，会看到一段 “vid：xxxx pdi: xxxx”，记住后面那段“path:x/x/x”
3.编辑Tiny目录下的TinyCoreLinux.vmx文件，把 usb.autoConnect.device1="path:0/0/2/2"，改成上面看到你自己的蓝牙路径

重新打开/恢复虚拟机，默认就会自动接管蓝牙，不用自己再操作；
这样就只用打开/关闭(休眠)虚拟机就行（中间隔个十几秒，给模块一点时间）；
